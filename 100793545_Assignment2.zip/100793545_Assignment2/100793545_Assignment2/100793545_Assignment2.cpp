// 100793545_Assignment2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

//Merging Function - We use this to compare two sub arrays, taking the smaller element and adding it to a temporary array
void merging(int array[], int leftsubarray, int midpoint, int rightsubarray)
{
	//Using the below variables to act as pointers to keep track of the index of the two sub arrays 
	
	int i = leftsubarray; //Beginning index for the left sub array
	int j = midpoint + 1; //Beginning index for the right sub array
	int k = leftsubarray; //Beginning index for the temporary array that contains all the sorted elements

	int temporaryArray[14]; //Temporary Array for sorted elements

	while (i <= midpoint && j <= rightsubarray) // i Iterates from the left side up to the mid point, j iterates from the mid point (+1) to the right
	{
		if (array[i] < array[j])
		{
			temporaryArray[k] = array[i]; //if array[i] is smaller than array[j]
			i++;
			k++;
		}
		else
		{
			temporaryArray[k] = array[j]; //if array[j] is smaller than array[i]
			j++;
			k++;
		}
	}

	while (i <= midpoint)
	{
		temporaryArray[k] = array[i]; //Copying the elements from the left sub array to the temporary array, as they are
		i++;
		k++;
	}

	while (j <= rightsubarray)
	{
		temporaryArray[k] = array[j]; //Copying the elements from the right sub array to the temporary array, as they are
		j++;
		k++;
	}

	for (int z = leftsubarray; z <= rightsubarray; z++) //Transferring sorted elements back into OG array
	{
		array[z] = temporaryArray[z];
	}

}


//MergeSort
void mergeSortFunction(int array[], int leftindex, int rightindex)
{
	if (leftindex < rightindex) //Array must have more than one element
	{
		int midpoint = (leftindex + rightindex) / 2; //Calculating midpoint
		
		mergeSortFunction(array, leftindex, midpoint); //In this case, the right index will be our newly calculated midpoint
		mergeSortFunction(array, midpoint+1, rightindex); //

		merging(array, leftindex, midpoint, rightindex); //Calling the merging function

	}
}

int main()
{
	int productID[14] = { 11, 1, 30, 2, 51, 6, 29, 7, 67, 15, 118, 4, 89, 23 };

	cout << "Below is our unsorted array: " << endl;

	for (int i = 0; i < 14 ; i++ )
		cout << productID[i] <<" ";
		cout << "" << endl;
		cout << "" << endl;

	mergeSortFunction(productID, 0, 13); 	//Merge Sort Functionality

	cout << "And now we have our sorted array below: " << endl;
	for (int i = 0; i < 14; i++)
		cout << productID[i] << " ";
		cout << "" << endl;
		cout << "" << endl;




	return 0;
}

